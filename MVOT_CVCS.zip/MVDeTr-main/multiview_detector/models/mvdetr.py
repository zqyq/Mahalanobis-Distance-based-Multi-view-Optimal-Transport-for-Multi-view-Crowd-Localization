import os
import numpy as np
import torch
import torch.nn as nn
from torchvision.models import vgg11
from multiview_detector.models.resnet import resnet18
from multiview_detector.utils.projection import get_worldcoord_from_imgcoord_mat, project_2d_points
import matplotlib.pyplot as plt
from multiview_detector.models.spatial_transformer_lowRes import spatial_transoformation_layer


def fill_fc_weights(layers):
    for m in layers.modules():
        if isinstance(m, nn.Conv2d):
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)


def output_head(in_dim, feat_dim, out_dim):
    if feat_dim:
        fc = nn.Sequential(nn.Conv2d(in_dim, feat_dim, 3, padding=1), nn.ReLU(),
                           nn.Conv2d(feat_dim, out_dim, 1))
    else:
        fc = nn.Sequential(nn.Conv2d(in_dim, out_dim, 1))
    return fc


def output_head2(in_dim, feat_dim=64, out_dim=1):
    fc = nn.Sequential(nn.Conv2d(in_dim, feat_dim, 3, padding=1), nn.ReLU(),
                       nn.Conv2d(feat_dim, feat_dim * 2, 3, padding=1), nn.ReLU(),
                       nn.Conv2d(feat_dim * 2, out_dim, 1))

    return fc


def create_reference_map(dataset, n_points=4, downsample=2, visualize=False):
    H, W = dataset.Rworld_shape  # H,W; N_row,N_col
    H, W = H // downsample, W // downsample

    ref_y, ref_x = torch.meshgrid(torch.linspace(0.5, H - 0.5, H, dtype=torch.float32),
                                  torch.linspace(0.5, W - 0.5, W, dtype=torch.float32))
    ref = torch.stack((ref_x, ref_y), -1).reshape([-1, 2])
    if n_points == 4:
        zs = [0, 0, 0, 0]
    elif n_points == 8:
        zs = [-0.4, -0.2, 0, 0, 0.2, 0.4, 1, 1.8]
    else:
        raise Exception
    ref_maps = torch.zeros([H * W, dataset.num_cam, n_points, 2])
    world_zoom_mat = np.diag([dataset.world_reduce * downsample, dataset.world_reduce * downsample, 1])
    Rworldgrid_from_worldcoord_mat = np.linalg.inv(
        dataset.base.worldcoord_from_worldgrid_mat @ world_zoom_mat @ dataset.base.world_indexing_from_xy_mat)
    for cam in range(dataset.num_cam):
        mat_0 = Rworldgrid_from_worldcoord_mat @ get_worldcoord_from_imgcoord_mat(dataset.base.intrinsic_matrices[cam],
                                                                                  dataset.base.extrinsic_matrices[cam])
        for i, z in enumerate(zs):
            mat_z = Rworldgrid_from_worldcoord_mat @ get_worldcoord_from_imgcoord_mat(
                dataset.base.intrinsic_matrices[cam],
                dataset.base.extrinsic_matrices[cam],
                z / dataset.base.worldcoord_unit)
            img_pts = project_2d_points(np.linalg.inv(mat_z), ref)
            ref_maps[:, cam, i, :] = torch.from_numpy(project_2d_points(mat_0, img_pts))
        pass
        if visualize:
            fig, ax = plt.subplots()
            field_x = (ref_maps[:, cam, 3, 0] - ref_maps[:, cam, 1, 0]).reshape([H, W])
            field_y = (ref_maps[:, cam, 3, 1] - ref_maps[:, cam, 1, 1]).reshape([H, W])
            ax.streamplot(ref_x.numpy(), ref_y.numpy(), field_x.numpy(), field_y.numpy())
            ax.set_aspect('equal', 'box')
            ax.invert_yaxis()
            plt.show()

    ref_maps[:, :, :, 0] /= W
    ref_maps[:, :, :, 1] /= H
    return ref_maps


class MVDeTr(nn.Module):
    def __init__(self, dataset, arch='resnet18', z=0, world_feat_arch='conv',
                 bottleneck_dim=512, outfeat_dim=64, droupout=0.5):
        super().__init__()

        self.view_size = 5
        self.num_cam = 5
        self.patch_num, self.cropped_size = 3, [200, 200]

        if arch == 'vgg11':
            self.base = vgg11(pretrained=False).features
            self.base[-1] = nn.Identity()
            self.base[-4] = nn.Identity()
            base_dim = 512
        elif arch == 'resnet18':
            self.base = nn.Sequential(*list(resnet18(pretrained=False,
                                                     replace_stride_with_dilation=[False, True, True]).children())[:-2])
            base_dim = 512
        else:
            raise Exception('architecture currently support [vgg11, resnet18]')


        # img heads
        self.img_heatmap1 = output_head(base_dim, outfeat_dim, 1)
        self.depth_scales = 1
        self.depth_classifier = nn.Sequential(nn.Conv2d(512, 64, 1), nn.ReLU(),
                                              nn.Conv2d(64, self.depth_scales, 1, bias=False))

        self.feat_before_merge = nn.ModuleDict({
            f'{i}': nn.Conv2d(512, 512, 3, padding=1)
            for i in range(self.depth_scales)
        })

        self.map_classifier_shot = nn.Sequential(nn.Conv2d(512, 512, 3, padding=1), nn.ReLU(),
                                            # # w/o large kernel
                                            # nn.Conv2d(512, 512, 3, padding=1), nn.ReLU(),
                                            # nn.Conv2d(512, 1, 3, padding=1, bias=False)).to('cuda:0')

                                            # with large kernel
                                            nn.Conv2d(512, 512, 3, padding=1), nn.ReLU(),
                                            nn.Conv2d(512, 1, 3, padding=1, bias=False),).to('cuda:0')


    def forward(self,
                imgs,
                camera_paras,
                wld_map_paras,
                hw_random,
                train=True,
                visualize=False):

        B, N, C, H, W = imgs.shape
        assert N == self.num_cam

        img_feat = self.base(imgs.reshape([B * N, C, H, W]))
        img_res = self.img_heatmap1(img_feat)
        img_res = img_res.reshape(B, self.num_cam, img_res.shape[-3], img_res.shape[-2], img_res.shape[-1])
        img_feat = img_feat.reshape(B, self.num_cam, img_feat.shape[-3], img_feat.shape[-2], img_feat.shape[-1])

        wf = []
        for batch in range(B):
            depth_select = self.depth_classifier(img_feat[batch]).softmax(dim=1)
            warped_feat = 0
            normalized_h = wld_map_paras[batch][5] / 1750.0
            muti_hei = [normalized_h * 1750]

            if train:
                paras = [1, self.view_size, self.patch_num, self.cropped_size]
            else:
                paras = [1, self.view_size, 1, [200 * (int(wld_map_paras[0, 3].item()) // 200 + 1),
                                                200 * (int(wld_map_paras[0, 4].item()) // 200 + 1)]]
                hw_random = torch.zeros((1, 2, 1), dtype=torch.int32)

            for i in range(self.depth_scales):
                in_feat = img_feat[batch] * depth_select[:, i][:, None]
                h = muti_hei[i]
                cur_height_f = []
                for cam in range(self.num_cam):
                    wld_map_paras[batch][5] = h
                    world_feature = spatial_transoformation_layer(paras,
                                                                  [in_feat[cam:cam+1].to('cuda:0'),
                                                                   camera_paras[batch][cam:cam + 1].to('cuda:0'),
                                                                   wld_map_paras[batch:batch+1].to('cuda:0'),
                                                                   hw_random[batch:batch+1].to('cuda:0')
                                                                   ])
                    cur_height_f.append(world_feature)
                    if len(cur_height_f) > 1:
                        t = torch.stack(cur_height_f, dim=1).max(1)[0]
                        cur_height_f = []
                        cur_height_f.append(t)

                warped_feat += self.feat_before_merge[f'{i}'](cur_height_f[0])
            wf.append(warped_feat)
        wf = torch.stack(wf, dim=0)
        batch, patch, C, w_H, w_W = wf.shape
        warped_feat = wf.reshape([batch*patch, C, w_H, w_W]).to('cuda:0')
        world_heatmap = self.map_classifier_shot(warped_feat)

        world_heatmap = torch.where(world_heatmap < 0, -world_heatmap, world_heatmap)
        if train:
            return world_heatmap.reshape(B, self.patch_num, world_heatmap.shape[-3], world_heatmap.shape[-2],
                                         world_heatmap.shape[-1]), img_res

        else:
            world_heatmap = torch.where(world_heatmap < 0, 0, world_heatmap)
            return world_heatmap.reshape(1, 1, world_heatmap.shape[-3], world_heatmap.shape[-2],
                                         world_heatmap.shape[-1]), img_res


def test():
    from multiview_detector.datasets.frameDataset import frameDataset
    from multiview_detector.datasets.Wildtrack import Wildtrack
    import torchvision.transforms as T
    from torch.utils.data import DataLoader
    from multiview_detector.utils.decode import ctdet_decode

    dataset = frameDataset(Wildtrack(os.path.expanduser('~/Data/Wildtrack')), train=False, augmentation=False)
    create_reference_map(dataset, 4)
    dataloader = DataLoader(dataset, 1, False, num_workers=0)
    model = MVDeTr(dataset, world_feat_arch='deform_trans').cuda()
    # model.load_state_dict(torch.load(
    #     '../../logs/wildtrack/augFCS_deform_trans_lr0.001_baseR0.1_neck128_out64_alpha1.0_id0_drop0.5_dropcam0.0_worldRK4_10_imgRK12_10_2021-04-09_22-39-28/MultiviewDetector.pth'))
    imgs, world_gt, imgs_gt, affine_mats, frame = next(iter(dataloader))
    imgs = imgs.cuda()
    (world_heatmap, world_offset), (imgs_heatmap, imgs_offset, imgs_wh) = model(imgs, affine_mats)
    xysc = ctdet_decode(world_heatmap, world_offset)
    pass


if __name__ == '__main__':
    test()
