import time
import os
import numpy as np
import torch
from torch import nn
from torch.cuda.amp import autocast
import matplotlib.pyplot as plt
from PIL import Image
from multiview_detector.loss import *
from multiview_detector.evaluation.evaluate import evaluate
from multiview_detector.utils.decode import ctdet_decode, mvdet_decode
from multiview_detector.utils.nms import nms
from multiview_detector.utils.meters import AverageMeter
from multiview_detector.utils.image_utils import add_heatmap_to_image, img_color_denormalize
from multiview_detector.loss.ot_loss.genloss import GeneralizedLoss
import torch.nn.functional as F
from multiview_detector.loss.gaussian_mse import GaussianMSE
import cv2



import time
import os
import numpy as np
import torch
from torch import nn
from torch.cuda.amp import autocast
import matplotlib.pyplot as plt
from PIL import Image
from multiview_detector.loss import *
from multiview_detector.evaluation.evaluate import evaluate
from multiview_detector.utils.decode import ctdet_decode, mvdet_decode
from multiview_detector.utils.nms import nms
from multiview_detector.utils.meters import AverageMeter
from multiview_detector.utils.image_utils import add_heatmap_to_image, img_color_denormalize
from multiview_detector.loss.ot_loss.genloss import GeneralizedLoss
import torch.nn.functional as F
from multiview_detector.loss.gaussian_mse import GaussianMSE
import cv2


class BaseTrainer(object):
    def __init__(self):
        super(BaseTrainer, self).__init__()


class PerspectiveTrainer(BaseTrainer):
    def __init__(self, model, logdir, cls_thres=0.4, alpha=1.0, use_mse=False, id_ratio=0):
        super(BaseTrainer, self).__init__()
        self.model = model
        self.mse_loss = nn.MSELoss()
        self.focal_loss = FocalLoss()
        self.regress_loss = RegL1Loss()
        self.ce_loss = RegCELoss()

        self.ot_loss_md = GeneralizedLoss(type='md')
        self.ot_loss_ed = GeneralizedLoss(type='ed')
        self.mse_loss = nn.MSELoss(reduction='mean')

        self.criterion = GaussianMSE().cuda()
        self.cls_thres = cls_thres
        self.logdir = logdir
        self.denormalize = img_color_denormalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
        self.alpha = alpha
        self.use_mse = use_mse
        self.id_ratio = id_ratio

    def train(self, batch, epoch, dataloader, optimizer, scaler, scheduler=None, log_interval=1):
        self.model.train()
        losses = 0
        t0 = time.time()
        t_b = time.time()
        t_forward = 0
        t_backward = 0
        for idx, (data, imgs_gt, camera_paras, wld_map_paras, hw_random, pmap_gt, dmap_gt, cam_loc) in enumerate(dataloader):
            imgs_gt = [img.to('cuda:0') for img in imgs_gt]
            data, camera_paras, wld_map_paras, hw_random = data.to('cuda:0'), camera_paras.to('cuda:0'), wld_map_paras.to('cuda:0'), hw_random.to('cuda:0')
            pmap_gt, dmap_gt, cam_loc = pmap_gt.to('cuda:0'), dmap_gt.to('cuda:0'), cam_loc.to('cuda:0')
            map_res, imgs_res = self.model(data, camera_paras, wld_map_paras, hw_random)

            loss_img = 0
            loss_w = 0
            for b in range(data.shape[0]):
                cur_map_gt = pmap_gt[b]
                for p in range(cur_map_gt.shape[0]):
                    cur_patch = cur_map_gt[p]
                    points = torch.nonzero(cur_patch) #y, x index
                    if points.shape[0] == 0:
                        loss_w = loss_w + torch.abs(map_res[b][p:p + 1, 0:1, ...]).mean()
                    else:
                        points = points / float(cur_map_gt.shape[-2])
                        points[:, [0, 1]] = points[:, [1, 0]]
                        points = points.unsqueeze(0).unsqueeze(0)
                        loss_w = loss_w + self.ot_loss_md(map_res[b][p:p + 1, 0:1, ...], points, cam_loc[b, p])


            for img_res, img_gt in zip(imgs_res, imgs_gt):
                loss_img += self.criterion(img_res, img_gt.to(img_res.device), dataloader.dataset.img_kernel)

            loss_total = loss_w / (data.shape[0] * 3.0) + loss_img / (data.shape[0] * 5.0)
            t_f = time.time()
            t_forward += t_f - t_b

            optimizer.zero_grad()
            loss_total.backward()
            optimizer.step()

            losses += loss_total.item()

            t_b = time.time()
            t_backward += t_b - t_f

            if scheduler is not None:
                if isinstance(scheduler, torch.optim.lr_scheduler.OneCycleLR):
                    scheduler.step()
                elif isinstance(scheduler, torch.optim.lr_scheduler.CosineAnnealingWarmRestarts) or \
                        isinstance(scheduler, torch.optim.lr_scheduler.LambdaLR):
                    scheduler.step(epoch - 1 + idx / len(dataloader))

            if (idx + 1) % log_interval == 0 or idx + 1 == len(dataloader):
                # print(cyclic_scheduler.last_epoch, optimizer.param_groups[0]['lr'])
                t1 = time.time()
                t_epoch = t1 - t0
                print(f'Train Epoch: {epoch}, Batch:{(idx + 1)}, loss: {losses / (idx + 1):.6f}, '
                      f'Time: {t_epoch:.1f}, maxima: {map_res.max():.3f}')


        del data, imgs_gt, camera_paras, wld_map_paras, hw_random, pmap_gt, dmap_gt, cam_loc, map_res, imgs_res
        torch.cuda.empty_cache()

        return losses / len(dataloader)


    def test(self, batch, epoch, data_loader, res_fpath=None, gt_fpath=None, visualize=False):
        self.model.eval()
        losses = 0
        precision_s, recall_s = AverageMeter(), AverageMeter()
        all_res_list = []
        all_gt_list = []

        t0 = time.time()
        if res_fpath is not None:
            assert gt_fpath is not None

        frame = 0

        for batch_idx, (data, imgs_gt, camera_paras, wld_map_paras, hw_random, map_gt, cam_loc, whole_plane_map) in enumerate(data_loader):
            data, camera_paras, wld_map_paras, hw_random = data.to('cuda:0'), camera_paras.to('cuda:0'), wld_map_paras.to('cuda:0'), hw_random.to('cuda:0')
            map_gt, cam_loc, whole_plane_map = map_gt.cuda(), cam_loc.cuda(), whole_plane_map.cuda()
            if map_gt.flatten().max == 0: #zq
                continue

            with torch.no_grad():
                map_res_mse, imgs_res = self.model(data, camera_paras, wld_map_paras, hw_random, train=False)

                loss_img = 0
                loss_w = 0
                for b in range(batch):
                    cur_map_res = map_res_mse[b][:, :, :int(wld_map_paras[0, 3].item()), :int(wld_map_paras[0, 4].item())]
                    cur_map_gt = whole_plane_map[b]

                    points = torch.nonzero(cur_map_gt)  # y, x index
                    if points.shape[0] == 0:
                        loss_w = loss_w + torch.abs(cur_map_res).mean()
                    else:
                        points = points / float(cur_map_gt.shape[-2])
                        points[:, [0, 1]] = points[:, [1, 0]]
                        points = points.unsqueeze(0).unsqueeze(0)
                        loss_w = loss_w + self.ot_loss_ed(map_res_mse[b], points, cam_loc[b, 0])#注意这里的相机参数无效

                losses = losses + loss_w.item()

                map_gt = whole_plane_map
                map_res_mse = map_res_mse[0][:, :, :int(wld_map_paras[0, 3].item()), :int(wld_map_paras[0, 4].item())]
                map_res_mse = (map_res_mse - torch.min(map_res_mse)) / (torch.max(map_res_mse) - torch.min(map_res_mse) + 1e-8)

            if res_fpath is not None:
                map_grid_res = map_res_mse.detach().cpu().squeeze()
                v_s = map_grid_res[map_grid_res > self.cls_thres].unsqueeze(1)
                grid_ij = (map_grid_res > self.cls_thres).nonzero()

                # gt:
                map_grid_gt = map_gt.detach().cpu().squeeze()
                v_s_gt = map_grid_gt[map_grid_gt > self.cls_thres].unsqueeze(1)
                grid_ij_gt = (map_grid_gt > self.cls_thres).nonzero()

                if data_loader.dataset.base.indexing == 'xy':
                    grid_xy = grid_ij[:, [1, 0]]
                    grid_xy_gt = grid_ij_gt[:, [1, 0]]
                else:
                    grid_xy = grid_ij
                    grid_xy_gt = grid_ij_gt

                frame = 1 + frame

                all_res_list.append(torch.cat([torch.ones_like(v_s) * frame, grid_xy.float(), v_s], dim=1))
                all_gt_list.append(torch.cat([(torch.ones_like(v_s_gt) * frame).float(), grid_xy_gt.float()], dim=1))


        t1 = time.time()
        t_epoch = t1 - t0

        if visualize:

            heatmap0_head = imgs_res[0][0, 0].detach().cpu().numpy().squeeze()
            img0 = self.denormalize(data[0, 0]).cpu().numpy().squeeze().transpose([1, 2, 0])
            img0 = Image.fromarray((img0 * 255).astype('uint8'))
            head_cam_result = add_heatmap_to_image(heatmap0_head, img0)
            head_cam_result.save(os.path.join(self.logdir, 'cam1_head.jpg'))

        del data, imgs_gt, camera_paras, wld_map_paras, hw_random, map_gt, cam_loc, whole_plane_map, map_res_mse, imgs_res
        torch.cuda.empty_cache()

        moda = 0
        if res_fpath is not None:
            all_res_list = torch.cat(all_res_list, dim=0)
            all_gt_list = torch.cat(all_gt_list, dim=0)

            np.savetxt(os.path.abspath(os.path.dirname(res_fpath)) + '/all_res.txt', all_res_list.numpy(), '%0.5f')
            np.savetxt(os.path.abspath(os.path.dirname(res_fpath)) + '/all_gt.txt', all_gt_list.numpy(), '%d')

            res_list = []
            gt_list = []
            for frame in np.unique(all_res_list[:, 0]):
                res = all_res_list[all_res_list[:, 0] == frame, :]
                positions, scores = res[:, 1:3], res[:, 3]
                ids, count = nms(positions, scores, 2.5, np.inf)
                res_list.append(torch.cat([torch.ones([count, 1]) * frame, positions[ids[:count], :]], dim=1))
            res_list = torch.cat(res_list, dim=0).numpy() if res_list else np.empty([0, 3])

            np.savetxt(res_fpath, res_list, '%d')

            recall, precision, moda, modp = evaluate(os.path.abspath(res_fpath), os.path.abspath(os.path.dirname(res_fpath)) + '/all_gt.txt',
                                                     data_loader.dataset.base.__name__)

            print('moda: {:.1f}%, modp: {:.1f}%, precision: {:.1f}%, recall: {:.1f}%'.
                  format(moda, modp, precision, recall))

        print('Test, Loss: {:.6f}, Precision: {:.1f}%, Recall: {:.1f}, \tTime: {:.3f}'.format(
            losses / (len(data_loader) + 1), precision_s.avg * 100, recall_s.avg * 100, t_epoch))

        return losses / len(data_loader), moda, modp


