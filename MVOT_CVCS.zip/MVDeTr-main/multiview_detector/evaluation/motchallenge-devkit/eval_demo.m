res_fpath = '../test-demo.txt';
gt_fpath = '../gt-demo.txt';

evaluateDetection(res_fpath, gt_fpath, 'wildtrack');