import torch


class EDCost:
    def __init__(self) -> None:
        pass

    def __call__(self, x, y):
        X, Y = x.clone(), y.clone()
        x_col = X.unsqueeze(-2)
        y_row = Y.unsqueeze(-3)
        C = torch.sqrt(torch.sum((x_col - y_row) ** 2, -1) + 1e-8)
        return torch.exp(C) - 1.0


class MDCost:
    def __init__(self):
        super().__init__()

        self.cam_posi1 = torch.tensor([126.4 / 1440, 480 / 1440 - 484 / 1440]).cuda()
        self.cam_posi2 = torch.tensor([1311.2 / 1440, 480 / 1440 - 74 / 1440]).cuda()
        self.cam_posi3 = torch.tensor([1068.4 / 1440, 480 / 1440 - 480 / 1440]).cuda()
        self.cam_posi4 = torch.tensor([126 / 1440, 480 / 1440 - 480 / 1440]).cuda()
        self.cam_posi5 = torch.tensor([735.2 / 1440, 480 / 1440 - (-39.6) / 1440]).cuda()
        self.cam_posi6 = torch.tensor([-65.6 / 1440, 480 / 1440 - 54.8 / 1440]).cuda()
        self.cam_posi7 = torch.tensor([434.8 / 1440, 480 / 1440 - 590.4 / 1440]).cuda()

    def __call__(self, x, y):

        X, Y = x.clone(), y.clone()
        X, Y = X.squeeze(0), Y.squeeze(0)

        X[:, 1] = 480 / 1440 - X[:, 1]

        Y[:, 1] = 480 / 1440 - Y[:, 1]

        calc = torch.stack((self.cam_posi1, self.cam_posi2, self.cam_posi3, self.cam_posi4, self.cam_posi5,
                            self.cam_posi6, self.cam_posi7), dim=0)
        maha_d = []
        gt2cam_dis = []

        for i in range(calc.shape[0]):
            direcY = Y - calc[i]

            rot_col1 = direcY.clone()
            abs_dy = torch.sqrt(torch.sum(direcY ** 2, -1))
            gt2cam_dis.append(abs_dy)

            abs_dy = (abs_dy - torch.min(abs_dy)) / (torch.max(abs_dy) - torch.min(abs_dy) + 1e-8)

            abs_dy = torch.exp(0.05 * abs_dy)

            sigma1 = torch.ones_like(abs_dy) * 1.0
            sigma2 = abs_dy


            inv_var = torch.zeros((abs_dy.shape[0], 2, 2)).cuda()
            inv_var[:, 0, 0] = 1 / sigma1
            inv_var[:, 1, 1] = 1 / sigma2

            rot_col1 = rot_col1 / torch.sqrt(rot_col1[:, 0] ** 2 + rot_col1[:, 1] ** 2).unsqueeze(-1)


            rot_col2 = rot_col1.clone()
            rot_col2[:, [0, 1]] = rot_col2[:, [1, 0]]
            rot_col2[:, 0] = -1 * rot_col2[:, 0]

            rot_col1 = rot_col1.unsqueeze(-1)
            rot_col2 = rot_col2.unsqueeze(-1)

            rot_mat = torch.concat((rot_col1, rot_col2), dim=-1)
            rot_mat_T = torch.permute(rot_mat, (0, 2, 1))

            inv_cov = torch.matmul(torch.matmul(rot_mat, inv_var), rot_mat_T)

            x_col = X.unsqueeze(-2)
            y_row = Y.unsqueeze(-3)
            diff_left = (x_col - y_row).unsqueeze(-2)
            diff_right = (x_col - y_row).unsqueeze(-1)

            mahalanobis_dis = torch.sqrt(
                torch.matmul(torch.matmul(diff_left, inv_cov), diff_right).squeeze(-1).squeeze(-1) + 1e-8)

            maha_d.append(mahalanobis_dis)


        maha_d = torch.stack(maha_d, dim=0)
        nearest_cam = torch.stack(gt2cam_dis, dim=0).min(0)[1]

        final_ma = torch.zeros_like(maha_d)[0]
        for i in range(nearest_cam.shape[0]):
            ind = nearest_cam[i]
            final_ma[:, i] = maha_d[ind, :, i]
        C = torch.exp(final_ma) - 1.
        C = C.unsqueeze(0)
        return C