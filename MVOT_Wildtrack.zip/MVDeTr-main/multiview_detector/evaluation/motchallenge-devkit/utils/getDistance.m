function dis=getDistance(x1,y1,x2,y2)    
% compute distance for two points
% 

    dis=0;
    
    dis = sqrt((x1 - x2)^2 + (y1 - y2)^2);
    
%     assert(dis<0,'something wrong with union computation');

end